# conftest.py
from dotenv import load_dotenv

load_result = load_dotenv(override=True)
